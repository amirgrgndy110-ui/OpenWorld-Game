نسخه اصلاح‌شده پروژه OpenWorld برای ساخت APK با GitHub Actions

تغییر اصلی:
- حذف تنظیمات gradle_build/min_sdk و gradle_build/target_sdk از export preset؛ این دو گزینه وقتی Use Gradle Build خاموش است نباید override شوند.
- فایل workflow در مسیر .github/workflows/android.yml قرار داده شده است.

روش استفاده:
1) محتویات این ZIP را در ریشه مخزن GitHub بارگذاری و فایل‌های هم‌نام را جایگزین کنید.
2) مطمئن شوید پوشه .github و فایل .github/workflows/android.yml نیز آپلود شده‌اند.
3) از تب Actions، ورک‌فلو Build OpenWorld Android APK را اجرا کنید.
4) در صورت موفقیت، فایل APK را از بخش Artifacts دانلود کنید.

نکته: این ZIP شامل پروژه و ورک‌فلو ساخت است؛ APK از قبل ساخته‌شده نیست.
