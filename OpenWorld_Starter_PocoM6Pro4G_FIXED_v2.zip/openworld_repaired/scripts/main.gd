extends Node3D

const CarScript = preload("res://scripts/player_car.gd")

var car: CharacterBody3D
var camera: Camera3D
var hud_label: Label
var touch_state := {"accelerate": false, "brake": false, "left": false, "right": false}

func _ready() -> void:
    _make_environment()
    _make_city()
    _make_car()
    _make_camera()
    _make_hud()

func _process(_delta: float) -> void:
    if car and hud_label:
        var speed_kmh := int(car.velocity.length() * 3.6)
        hud_label.text = "OPEN WORLD  |  %d km/h" % speed_kmh

func _make_environment() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.78, 0.88)
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    add_child(sun)

    var ground := StaticBody3D.new()
    ground.name = "Ground"
    var ground_mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(220, 220)
    ground_mesh.mesh = plane
    var ground_mat := StandardMaterial3D.new()
    ground_mat.albedo_color = Color(0.20, 0.34, 0.22)
    ground_mat.roughness = 1.0
    ground_mesh.material_override = ground_mat
    ground.add_child(ground_mesh)
    var ground_collision := CollisionShape3D.new()
    var ground_shape := BoxShape3D.new()
    ground_shape.size = Vector3(220, 0.2, 220)
    ground_collision.shape = ground_shape
    ground_collision.position.y = -0.1
    ground.add_child(ground_collision)
    add_child(ground)

func _make_city() -> void:
    _add_road(Vector3(0, 0.02, 0), Vector3(12, 0.04, 180))
    _add_road(Vector3(0, 0.03, 0), Vector3(180, 0.04, 12))
    _add_road(Vector3(35, 0.025, 30), Vector3(8, 0.04, 100))
    _add_road(Vector3(-42, 0.025, -28), Vector3(8, 0.04, 100))

    var rng := RandomNumberGenerator.new()
    rng.seed = 2026
    for x in range(-4, 5):
        for z in range(-4, 5):
            if abs(x) <= 1 or abs(z) <= 1:
                continue
            var height := rng.randf_range(7.0, 25.0)
            var width := rng.randf_range(7.0, 12.0)
            var depth := rng.randf_range(7.0, 12.0)
            var pos := Vector3(x * 24.0 + rng.randf_range(-3, 3), height / 2.0, z * 24.0 + rng.randf_range(-3, 3))
            _add_building(pos, Vector3(width, height, depth), rng)

func _add_road(pos: Vector3, size: Vector3) -> void:
    var road := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    road.mesh = mesh
    road.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.075, 0.085, 0.10)
    mat.roughness = 0.95
    road.material_override = mat
    add_child(road)

func _add_building(pos: Vector3, size: Vector3, rng: RandomNumberGenerator) -> void:
    var building := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    building.mesh = mesh
    building.position = pos
    var mat := StandardMaterial3D.new()
    var shade := rng.randf_range(0.25, 0.58)
    mat.albedo_color = Color(shade, shade * 1.08, shade * 1.18)
    mat.roughness = 0.88
    building.material_override = mat
    add_child(building)

func _make_car() -> void:
    car = CharacterBody3D.new()
    car.name = "PlayerCar"
    car.position = Vector3(0, 1.0, 8)
    car.set_script(CarScript)
    add_child(car)

    var body_mesh := MeshInstance3D.new()
    var body := BoxMesh.new()
    body.size = Vector3(2.0, 0.65, 4.0)
    body_mesh.mesh = body
    body_mesh.position.y = 0.55
    var paint := StandardMaterial3D.new()
    paint.albedo_color = Color(0.78, 0.045, 0.025)
    paint.metallic = 0.65
    paint.roughness = 0.28
    body_mesh.material_override = paint
    car.add_child(body_mesh)

    var cabin := MeshInstance3D.new()
    var cabin_mesh := BoxMesh.new()
    cabin_mesh.size = Vector3(1.55, 0.65, 1.8)
    cabin.mesh = cabin_mesh
    cabin.position = Vector3(0, 1.15, -0.25)
    var glass := StandardMaterial3D.new()
    glass.albedo_color = Color(0.055, 0.13, 0.19)
    glass.metallic = 0.35
    glass.roughness = 0.18
    cabin.material_override = glass
    car.add_child(cabin)

    for x in [-0.92, 0.92]:
        for z in [-1.25, 1.25]:
            var wheel := MeshInstance3D.new()
            var wheel_mesh := CylinderMesh.new()
            wheel_mesh.top_radius = 0.38
            wheel_mesh.bottom_radius = 0.38
            wheel_mesh.height = 0.24
            wheel.mesh = wheel_mesh
            wheel.rotation_degrees.z = 90
            wheel.position = Vector3(x, 0.28, z)
            var rubber := StandardMaterial3D.new()
            rubber.albedo_color = Color(0.025, 0.025, 0.028)
            wheel.material_override = rubber
            car.add_child(wheel)

    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(2.0, 1.25, 4.0)
    collision.shape = shape
    collision.position.y = 0.55
    car.add_child(collision)

func _make_camera() -> void:
    camera = Camera3D.new()
    camera.name = "FollowCamera"
    camera.current = true
    camera.fov = 75.0
    add_child(camera)
    camera.position = Vector3(0, 5, 14)
    camera.look_at(car.global_position, Vector3.UP)

func _make_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(root)

    hud_label = Label.new()
    hud_label.position = Vector2(24, 18)
    hud_label.add_theme_font_size_override("font_size", 25)
    hud_label.add_theme_color_override("font_color", Color.WHITE)
    hud_label.text = "OPEN WORLD  |  0 km/h"
    root.add_child(hud_label)

    _add_control_button(root, "◀", Vector2(28, -118), "left")
    _add_control_button(root, "▶", Vector2(118, -118), "right")
    _add_control_button(root, "BRAKE", Vector2(-220, -118), "brake")
    _add_control_button(root, "GAS", Vector2(-112, -118), "accelerate")

func _add_control_button(parent: Control, caption: String, offset: Vector2, action: String) -> void:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(82, 82)
    button.anchor_left = 0.0 if action in ["left", "right"] else 1.0
    button.anchor_right = button.anchor_left
    button.anchor_top = 1.0
    button.anchor_bottom = 1.0
    button.position = offset
    button.add_theme_font_size_override("font_size", 19)
    button.modulate = Color(1, 1, 1, 0.82)
    parent.add_child(button)
    button.button_down.connect(_set_touch.bind(action, true))
    button.button_up.connect(_set_touch.bind(action, false))

func _set_touch(action: String, pressed: bool) -> void:
    touch_state[action] = pressed

func get_touch_state(action: String) -> bool:
    return touch_state.get(action, false)

func _process_camera(delta: float) -> void:
    pass

func _physics_process(delta: float) -> void:
    if not car or not camera:
        return
    var behind := car.global_transform.basis * Vector3(0, 4.8, 10.5)
    var target_pos := car.global_position + behind
    camera.global_position = camera.global_position.lerp(target_pos, 1.0 - exp(-4.0 * delta))
    camera.look_at(car.global_position + Vector3(0, 1.0, 0), Vector3.UP)
