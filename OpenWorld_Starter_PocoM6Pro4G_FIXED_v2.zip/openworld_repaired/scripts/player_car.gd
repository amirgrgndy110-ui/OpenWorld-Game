extends CharacterBody3D

@export var acceleration := 17.0
@export var reverse_acceleration := 8.0
@export var max_speed := 34.0
@export var max_reverse_speed := 10.0
@export var steering_speed := 1.65
@export var drag := 7.0

var speed := 0.0

func _physics_process(delta: float) -> void:
    var world := get_parent()
    var accelerate := false
    var brake := false
    var left := false
    var right := false

    if world and world.has_method("get_touch_state"):
        accelerate = world.get_touch_state("accelerate")
        brake = world.get_touch_state("brake")
        left = world.get_touch_state("left")
        right = world.get_touch_state("right")

    # Keyboard fallback for testing in the editor.
    accelerate = accelerate or Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)
    brake = brake or Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN)
    left = left or Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT)
    right = right or Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)

    if accelerate:
        speed = move_toward(speed, max_speed, acceleration * delta)
    elif brake:
        if speed > 0.8:
            speed = move_toward(speed, 0.0, acceleration * 1.8 * delta)
        else:
            speed = move_toward(speed, -max_reverse_speed, reverse_acceleration * delta)
    else:
        speed = move_toward(speed, 0.0, drag * delta)

    var steering := float(right) - float(left)
    var steering_factor := clamp(abs(speed) / 7.0, 0.0, 1.0)
    if abs(speed) > 0.2:
        rotate_y(-steering * steering_speed * steering_factor * delta * sign(speed))

    var forward := -global_transform.basis.z
    velocity.x = forward.x * speed
    velocity.z = forward.z * speed
    velocity.y -= 22.0 * delta
    move_and_slide()

    if is_on_floor() and velocity.y < 0.0:
        velocity.y = 0.0
